# GC001 逐分钟盘口信号回测与强化学习研究

## 目标

验证"盘口信号只需每个交易分钟开头几根 tick 即可决策"的假设，并把
eat / wallgone / jump / ofi 四类信号从单一 09:30 窗口扩展到全天任意分钟。
通过参数网格回测与按天留一的上下文赌博机评估，寻找一般规律。

## 方法

### 数据

- 全天五档 tick：2026-07-31（09:15–11:20）与 2026-08-06（09:30–11:30），
  约每分钟 20 帧；
- 早盘窗口：2026-08-07（09:30–09:35）。
- 说明：全天五档数据当前仅两个上午段，样本量小；结论是机制验证与方向参考，
  不构成统计显著性。

### 决策与成交代理

- 每个交易分钟开头 `decision_seconds=6` 秒内的 tick（至少 2 根）喂入
  `IncrementalSignalEngine`，取最后一帧特征；
- 用 `triggers()` / `pick_trigger()` 判定 eat / wallgone / jump / ofi；
- 触发后模拟挂 1000 元限价卖单：`anchor(ask1/micro1) + offset*tick`；
- 成交代理：后续 `hold_seconds=60` 秒内任一帧 `ask1 >= L` 或
  `lastPrice >= L` 即视为成交，成交价按 L 计；
- 收益 = 成交收益（bp）= `(L - 决策时刻 lastPrice) * 100`；未成交记 0。

## 结果（236 个分钟 episode）

### 按触发类型

| trigger | n | fill_rate | avg_reward_bp_filled | total_reward_bp |
|---|---:|---:|---:|---:|
| wallgone | 6 | 0.667 | 2.875 | 11.5 |
| eat | 6 | 0.667 | 1.500 | 6.0 |
| jump | 1 | 1.000 | 1.500 | 1.5 |
| none | 223 | - | - | 0.0 |

### 参数网格（offset × hold，统一 offset）

最优：offset=4（fill_rate 84.6%，avg_reward 1.923 bp，total 25.0 bp）；
offset=3 次之（fill 84.6%，avg 1.5 bp）。hold 30/60/90 秒对结果影响很小。

### 上下文赌博机（按天留一，岭回归）

- OOS 平均收益：0.0551 bp（合计 13.0 bp / 236 分钟）；
- 对照"任何信号触发即交易"基线：0.0805 bp（合计 19.0 bp）；
- 空仓基线：0。

当前样本下 RL 学习策略未明显优于"信号触发即交易"的简单基线，且远小于
参数网格中固定 offset=4 的潜在收益（受留一评估样本量限制）。

## 初步规律与下一步

1. wallgone / eat 在分钟尺度上仍有一定正向收益与 2/3 成交率，方向与早盘
   窗口研究一致，但样本过少，不能当作可交易结论。
2. 逐分钟框架已可用（`scripts/gc001_per_minute_signal_backtest.py`），
   可直接喂入未来累积的全天 tick 数据重跑网格与 RL。
3. 建议先积累多日全天五档 tick（例如每天被动采集 09:30–15:00），再用
   按天留一评估判断参数与策略是否稳定；单日模拟盘对信号研究无增量价值。

> 本页为只读研究结论，不构成投资建议；成交代理忽略排队风险。

---

## 补充：244 天 1 分钟 OHLC 回测（更大样本）

由于五档 tick 目前只有两个上午段，为进一步验证"逐分钟决策"的一般规律，
增加了基于 244 天 1 分钟 OHLC 的回测
（`scripts/gc001_per_minute_ohlc_backtest.py`，数据
`data/gc001_kronos/gc001_1m_extended_20260806.csv`）。

成交代理：每分钟以该分钟 `open` 为决策基准，挂 1000 元限价卖单
`L = open + offset*tick`；后续 `hold` 分钟内任一分钟 `high >= L` 即视为
成交，成交价按 L 计；未成交收益 0。收益 = `(L - open) * 100`（bp）。

### 结果（59,511 个分钟 episode，244 个交易日）

参数网格（offset × hold）最优：

| offset | hold(分钟) | fill_rate | avg_reward_bp | total_reward_bp |
|---:|---:|---:|---:|---:|
| 4 | 30 | 0.5149 | 1.0298 | 61284.0 |
| 5 | 30 | 0.3990 | 0.9976 | 59367.5 |
| 3 | 30 | 0.6527 | 0.9790 | 58260.0 |

按天留一线性赌博机：

- OOS 平均收益 0.338 bp（合计 20113.5 bp）；
- "任何分钟都挂单"基线 0.4902 bp（合计 29175.0 bp）。

结论：在 244 天、约 6 万个分钟样本上，简单的"预测收益 > 0 才交易"线性
策略没有跑赢"每分钟都按固定 offset 挂单"的全交易基线；说明分钟级
`open + offset` 固定挂单的期望收益主要来自 offset 选择与成交代理假设，
而不是可被线性特征显著改善的择时。这是负向但重要的证据：真正的价值可能
在五档盘口信号（eat/wallgone）或更高频 tick 特征，而不是 1 分钟 OHLC
线性择时。待全天五档 tick 数据积累后，应优先用盘口特征重跑同一套
按天留一评估。

注意：OHLC 版没有五档盘口，不能计算 eat/wallgone；该脚本用于扩大样本
验证"逐分钟决策"的一般规律，与 tick 版互补。

### 分钟时段模式分析（244 天，hold=30）

对每个交易分钟统计各 offset 的成交率与平均收益，并给出该分钟的最优
offset（`minute_pattern_analysis`）。收益最高的分钟时段：

| minute | best_offset | best_avg_reward_bp | best_fill_rate |
|---|---:|---:|---:|
| 09:31 | 6 | 2.048 | 0.683 |
| 09:30 | 6 | 1.687 | 0.562 |
| 14:32 | 6 | 1.663 | 0.554 |
| 14:31 | 6 | 1.651 | 0.550 |
| 14:30–14:36 | 6 | 1.60–1.65 | 0.53–0.55 |

规律：**开盘第 1–2 分钟与收盘前 24–30 分钟是分钟级"挂更高价仍能成交"
收益最高的时段，且最优 offset 稳定为 6**（与早盘窗口 wallgone 采用大
offset 的设计一致）。中间交易时段收益明显更低、最优 offset 更小，说明
盘口驱动的高收益机会集中在开盘与尾盘，而非全天均匀分布。

这是 244 天、每时段约 249 个样本上的一致规律；作为可执行方向，值得在
未来全天五档 tick 数据上用 eat/wallgone 特征验证开盘 09:31 与尾盘
14:30–14:36 这两个窗口。

## 数据采集与窗口聚焦评估（已部署）

为验证上述规律在五档盘口信号上是否成立，已部署只读的全天 tick 采集任务：

- 任务：`miniQMT GC001 Full-Day Tick Collector`（周一至周五 09:15 启动，
  采集至 15:31，写入 `D:\gitee\miniQMT\data\gc001_ticks\date=YYYYMMDD\`）；
- 该任务只订阅行情、绝不连接交易通道；
- 管理脚本：`D:\gitee\miniQMT\scripts\manage_gc001_full_day_tick_collector_task.ps1`
  （Install / Remove / Status / Enable / Disable）。

tick 版回测现已支持窗口过滤，可只评估指定分钟：

```powershell
.\venv\Scripts\python.exe scripts\gc001_per_minute_signal_backtest.py `
  --minutes "09:31:00,14:30:00,14:31:00,14:32:00,14:33:00,14:34:00,14:35:00,14:36:00" `
  --output reports\gc001_per_minute_signal\windows_0931_1430
```

当前仅有上午 tick 数据，14:30–14:36 窗口样本为空；全天采集积累多日后，
用同一命令即可对该窗口做 eat/wallgone 的按天留一评估，验证 offset=6
的参数是否稳定。

### 缓存补回（当天漏采时使用）

全天实时采集任务上线前，或某天任务未运行时，可在收盘后从 QMT 本地缓存
补回当天全天五档 tick：

```powershell
.\venv\Scripts\python.exe D:\gitee\miniQMT\scripts\export_gc001_daily_from_cache.py `
  --trade-date 2026-08-07
```

输出写入 `data\gc001_morning\date=YYYYMMDD\gc001_daily_l1_from_cache.jsonl`，
覆盖 09:15–15:30（前提：当天 QMT 终端在线且有 204001 行情订阅）。该文件已
加入 tick 回测默认输入，按天留一评估会把它作为一个独立交易日参与交叉验证。

2026-08-07 即通过缓存补回：5604 帧、283 个交易分钟、14:30–14:36 每窗口
20 帧；补回后四源回测 episode 数从 236 增至 470。
